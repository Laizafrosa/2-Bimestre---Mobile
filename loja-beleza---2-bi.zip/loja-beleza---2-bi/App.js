import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  View,
  Text,
  TextInput,
  Button,
  Image,
  TouchableOpacity,
} from 'react-native';

const Stack = createStackNavigator();

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (username === 'admin' && password === '1234') {
      navigation.navigate('Products');
    } else {
      alert('Usuário ou senha incorretos');
    }
  };

  return (
    <View style={styles.loginContainer}>
      <Image
        source={require('./assets/logo.jpg')} 
        style={styles.logo}
      />
      <TextInput
        style={styles.input}
        placeholder="Usuário"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <Button title="Entrar" onPress={handleLogin} />
    </View>
  );
};

const ProductsScreen = ({ navigation }) => {
  const products = [
    {
      image: 'https://www.drogasil.com.br/_next/image?url=https%3A%2F%2Fproduct-data.raiadrogasil.io%2Fimages%2F3838335.webp%3Fwidth%3D450%26height%3D450%26quality%3D85%26type%3Dresize&w=640&q=85',
      name: 'Creme Hidratante',
      price: 49.99,
      details: 'Creme hidratante para pele seca, perfeito para hidratação diária.',
    },
    {
      image: 'https://brunatavares.vtexassets.com/arquivos/ids/156108/THAIS.png?v=638004018694670000',
      name: 'Batom Matte',
      price: 29.99,
      details: 'Batom com acabamento matte, disponível em diversas cores vibrantes.',
    },
    {
      image: 'https://imgs.casasbahia.com.br/1565476999/1xg.jpg',
      name: 'Perfume Feminino',
      price: 99.99,
      details: 'Perfume floral delicado, ideal para ocasiões especiais.',
    },
    {
      image: 'https://oceane.vtexassets.com/arquivos/ids/202577-800-800?v=638350644050100000&width=800&height=800&aspect=true',
      name: 'Kit de Maquiagem',
      price: 89.99,
      details: 'Kit completo de maquiagem com sombras, blush e batons.',
    },
  ];

  return (
    <ScrollView contentContainerStyle={styles.productsContainer}>
      <SafeAreaView style={styles.productsGrid}>
        {products.map((product) => (
          <TouchableOpacity
            key={product.id}
            style={styles.product}
            onPress={() => navigation.navigate('ProductDetails', { product })}
          >
            <Image source={{ uri: product.image }} style={styles.productImage} />
            <Text style={styles.productName}>{product.name}</Text>
            <Text style={styles.productPrice}>R$ {product.price.toFixed(2)}</Text>
          </TouchableOpacity>
        ))}
      </SafeAreaView>
    </ScrollView>
  );
};

const ProductDetailsScreen = ({ route }) => {
  const { product } = route.params;

  return (
    <View style={styles.detailsContainer}>
      <Image source={{ uri: product.image }} style={styles.detailImage} />
      <Text style={styles.detailName}>{product.name}</Text>
      <Text style={styles.detailDescription}>{product.details}</Text>
      <Text style={styles.detailPrice}>Preco: R$ {product.price.toFixed(2)}</Text>
    </View>
  );
};

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Products" component={ProductsScreen} />
        <Stack.Screen
          name="ProductDetails"
          component={ProductDetailsScreen}
          options={{ title: 'Detalhes do Produto' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loginContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFFFFF',
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 30,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 15,
    paddingLeft: 10,
    borderRadius: 5,
  },
  productsContainer: {
    alignItems: 'center',
    paddingVertical: 10,
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    width: '100%',
  },
  product: {
    width: '45%',
    backgroundColor: '#fff',
    borderRadius: 8,
    marginBottom: 20,
    alignItems: 'center',
    padding: 10,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  productImage: {
    width: 100,
    height: 100,
    marginBottom: 10,
    borderRadius: 8,
  },
  productName: {
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 5,
  },
  productPrice: {
    fontSize: 14,
    color: 'black',
  },
  detailsContainer: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
  },
  detailImage: {
    width: 200,
    height: 200,
    marginBottom: 20,
  },
  detailName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  detailDescription: {
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'center',
  },
  detailPrice: {
    fontSize: 18,
    marginTop: 10,
  },
});
